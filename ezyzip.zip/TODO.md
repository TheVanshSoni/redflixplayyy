## TODO

* [x] Progress Bar / Timeline / Scrubber
* [x] Background Gradient
* [x] Hover effects on each button
  * Button background is transparent
  * On hover remove transparency
* [x] Basic playback controls working with JS
* [x] Change button icons based on player state
* [ ] Controls dissapear after 5 seconds of no activity
* [ ] Controls to auto appear on hover